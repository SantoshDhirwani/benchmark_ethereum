In this folder we store the aggregated results
