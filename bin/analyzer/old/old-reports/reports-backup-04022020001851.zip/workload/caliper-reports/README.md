In this folder we store caliper reports
